#!/bin/bash

while true
do
./wildrig-multi --print-full --algo ghostrider --url stratum+tcp://stratum-eu.rplant.xyz:7056 --user RCQMzucqevALkHCPKH7xrp5ieLUBwmhLYq --pass x
sleep 5
done
